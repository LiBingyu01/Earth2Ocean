#!/bin/bash

WORK_DIR_BASE=$1
MODEL_TYPE=$2
BETA=$3
GAMMA=$4
VFM_MODEL=$5
GEOFEATS_IDX=$6
SIMILARITY_THRES=$7
MAX_WEIGHT=$8
MLLM_TYPE=$9

# ================= AquaOV255
python eval.py --config configs/cfg_AquaOV255.py \
 --work-dir ./${WORK_DIR_BASE}/AquaOV255_${MODEL_TYPE}_${MLLM_TYPE} \
 --model_type ${MODEL_TYPE} \
 --beta ${BETA} \
 --gamma ${GAMMA} \
 --vfm_model ${VFM_MODEL} \
 --geofeats_idx ${GEOFEATS_IDX} \
 --similarity_threshold ${SIMILARITY_THRES} \
 --max_weight ${MAX_WEIGHT} \
 --use_uwtemplate \
 --use_mllm \
 --mllm_type ${MLLM_TYPE}
 
# ================= usis16k
python eval.py --config configs/cfg_usis16k.py \
 --work-dir ./${WORK_DIR_BASE}/usis16k_${MODEL_TYPE}_${MLLM_TYPE} \
 --model_type ${MODEL_TYPE} \
 --beta ${BETA} \
 --gamma ${GAMMA} \
 --vfm_model ${VFM_MODEL} \
 --geofeats_idx ${GEOFEATS_IDX} \
 --similarity_threshold ${SIMILARITY_THRES} \
 --max_weight ${MAX_WEIGHT} \
 --use_uwtemplate \
 --use_mllm \
 --mllm_type ${MLLM_TYPE}

# ================= mas3k
python eval.py --config configs/cfg_mas3k.py \
  --work-dir ./${WORK_DIR_BASE}/mas3k_${MODEL_TYPE}_${MLLM_TYPE} \
  --model_type ${MODEL_TYPE} \
  --beta ${BETA} \
  --gamma ${GAMMA} \
  --vfm_model ${VFM_MODEL} \
  --geofeats_idx ${GEOFEATS_IDX} \
  --similarity_threshold ${SIMILARITY_THRES} \
  --max_weight ${MAX_WEIGHT} \
  --use_uwtemplate \
  --use_mllm \
  --mllm_type ${MLLM_TYPE}

# ================= dutuseg
python eval.py --config configs/cfg_dutuseg.py \
 --work-dir ./${WORK_DIR_BASE}/dutuseg_${MODEL_TYPE}_${MLLM_TYPE} \
 --model_type ${MODEL_TYPE} \
 --beta ${BETA} \
 --gamma ${GAMMA} \
 --vfm_model ${VFM_MODEL} \
 --geofeats_idx ${GEOFEATS_IDX} \
 --similarity_threshold ${SIMILARITY_THRES} \
 --max_weight ${MAX_WEIGHT} \
 --use_uwtemplate \
 --use_mllm \
 --mllm_type ${MLLM_TYPE}

# ================= suimtrainval
python eval.py --config configs/cfg_suimtrainval.py \
 --work-dir ./${WORK_DIR_BASE}/suimtrainval_${MODEL_TYPE}_${MLLM_TYPE} \
 --model_type ${MODEL_TYPE} \
 --beta ${BETA} \
 --gamma ${GAMMA} \
 --vfm_model ${VFM_MODEL} \
 --geofeats_idx ${GEOFEATS_IDX} \
 --similarity_threshold ${SIMILARITY_THRES} \
 --max_weight ${MAX_WEIGHT} \
 --use_uwtemplate \
 --use_mllm \
 --mllm_type ${MLLM_TYPE}

# ================= usis10kvaltest
python eval.py --config configs/cfg_usis10kvaltest.py \
 --work-dir ./${WORK_DIR_BASE}/usis10kvaltest_${MODEL_TYPE}_${MLLM_TYPE} \
 --model_type ${MODEL_TYPE} \
 --beta ${BETA} \
 --gamma ${GAMMA} \
 --vfm_model ${VFM_MODEL} \
 --geofeats_idx ${GEOFEATS_IDX} \
 --similarity_threshold ${SIMILARITY_THRES} \
 --max_weight ${MAX_WEIGHT} \
 --use_uwtemplate \
 --use_mllm \
 --mllm_type ${MLLM_TYPE}