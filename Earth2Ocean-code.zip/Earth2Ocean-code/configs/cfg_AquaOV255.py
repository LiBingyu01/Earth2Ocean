_base_ = './base_config.py'

# model settings
model = dict(
    name_path='configs/cls_AquaOV255.txt',
    json_path='configs/llm_reasoning_AquaOV255.json',
    imgname_list_path='configs/imglist_AquaOV255.txt'
)
# dataset settings
dataset_type = 'AquaOV255'
data_root = 'datasets/AquaOV255'

test_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='Resize', scale=(2048, 336), keep_ratio=True),
    dict(type='LoadAnnotations'),
    dict(type='PackSegInputs')
]

test_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(
            img_path='images', seg_map_path='masks'),
        pipeline=test_pipeline))