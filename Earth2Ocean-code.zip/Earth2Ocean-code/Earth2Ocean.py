import torch
import torch.nn as nn
import sys

sys.path.append("..")

from prompts.imagenet_template import openai_imagenet_template, sub_imagenet_template, openai_underwater_template

from mmseg.models.segmentors import BaseSegmentor
from mmseg.models.data_preprocessor import SegDataPreProcessor
from mmengine.structures import PixelData
from mmseg.registry import MODELS
from torchvision import transforms
import torch.nn.functional as F
from einops import rearrange

from open_clip import create_model, tokenizer
from myutils import UnNormalize
from vision_transformer import vit_base

from typing import Optional
from depth_anything_v2.dpt import DepthAnythingV2
from tqdm import tqdm
import json
import os

def _build_depthanything(weights: Optional[str] = None, model_type: str = "small") -> Optional[nn.Module]:
    DEVICE = 'cuda' if torch.cuda.is_available() else 'mps' if torch.backends.mps.is_available() else 'cpu'
    model_configs = {
        'vits': {'encoder': 'vits', 'features': 64, 'out_channels': [48, 96, 192, 384]},
        'vitb': {'encoder': 'vitb', 'features': 128, 'out_channels': [96, 192, 384, 768]},
        'vitl': {'encoder': 'vitl', 'features': 256, 'out_channels': [256, 512, 1024, 1024]},
        'vitg': {'encoder': 'vitg', 'features': 384, 'out_channels': [1536, 1536, 1536, 1536]}
    }

    model = DepthAnythingV2(**model_configs[model_type])
    model.load_state_dict(torch.load(f'pretrained_ckpt/depth_anything_v2_{model_type}.pth', map_location='cpu'))
    model = model.to(DEVICE).eval()
    for p in model.parameters():
        p.requires_grad_(False)
    return model

@MODELS.register_module()
class Earth2OceanSegmentation(BaseSegmentor):
    def __init__(self, 
                 clip_type, 
                 model_type,
                 json_path,
                 imgname_list_path,
                 name_path, 
                 checkpoint=None, 
                 device=torch.device('cuda'),
                 prob_thd=0.0, 
                 logit_scale=40, 
                 # Geometric-guided Visual Mask Generator
                 beta=1.2, 
                 gamma=3.0, 
                 vfm_model='geometric',
                 geofeats_idx='3',
                 # Category-visual Semantic Alignment
                 similarity_threshold=0.5,
                 max_weight=0.5,
                 use_uwtemplate=True,
                 use_mllm=True,
                 mllm_type="4o",
                 show=False,
                 show_dir="./show_dir",
                 slide_stride=112, 
                 slide_crop=336):

        data_preprocessor = SegDataPreProcessor(
            mean=[122.771, 116.746, 104.094],
            std=[68.501, 66.632, 70.323],
            bgr_to_rgb=True
        )
        super().__init__(data_preprocessor=data_preprocessor)

        self.device = device
        self.show = show
        self.show_dir = show_dir

        self.clip = create_model(model_type, pretrained=clip_type, precision='fp16')
        self.clip.eval().to(device)
        self.tokenizer = tokenizer.tokenize

        # Geometric-guided Visual Mask Generator
        self.vfm_model = vfm_model
        if vfm_model == "nongeometric":
            self.vfm = vit_base(patch_size=8, num_classes=0)
            self.vfm.load_state_dict(torch.load('pretrained_ckpt/dino_vitbase8_pretrain.pth'))
        elif vfm_model == "geometric":
            self.vfm = _build_depthanything("pretrained_ckpt/depth_anything_v2_vitb.pth", "vitb")
        self.geofeats_idx = geofeats_idx
        
        self.vfm = self.vfm.half()
        for p in self.vfm.parameters():
            p.requires_grad = False
        self.vfm.eval().to(device)

# startfor ============================= Category-visual Semantic Alignment
        # MLLM reasoning
        if use_mllm:
            # LLM 
            if mllm_type == "4o":
                json_path = json_path.replace(".json", "_4o.json")
            elif mllm_type == "qwen3b":
                json_path = json_path.replace(".json", "_qwen3b.json")
            elif mllm_type == "qwen7b":
                json_path = json_path.replace(".json", "_qwen7b.json")

            with open(f"{json_path}", "r", encoding="utf-8") as f:
                image_captions = json.load(f)

            with open(imgname_list_path, "r", encoding="utf-8") as f:
                img_list = [line.strip() for line in f if line.strip()]

            dict_llm_embedding = {}
            for img_name in tqdm(img_list, desc="Encoding objects"):
                if img_name not in image_captions:
                    print(f"Warning: {img_name} not found in JSON.")
                    dict_llm_embedding[img_name] = {
                        "obj": None,
                    }
                    continue
                json_data = image_captions[img_name]
                text_prompts = self.build_prompts_from_json(json_data)
                if not text_prompts:
                    dict_llm_embedding[img_name] = {
                    "obj": None,
                    }       
                    continue

                # embedding
                with torch.no_grad():
                    text_tokens = self.tokenizer(text_prompts).to(device)
                    text_emb = self.clip.encode_text(text_tokens)
                    text_emb = text_emb / text_emb.norm(dim=-1, keepdim=True)  # 归一化

                # to CPU
                obj_embeddings_list = text_emb.detach().cpu()

                dict_llm_embedding[img_name] = {
                    "obj": obj_embeddings_list,
                }
            self.dict_llm_embedding = dict_llm_embedding
        else:
            self.dict_llm_embedding = None

        # Underwater templates
        query_words, self.query_idx = get_cls_idx(name_path)
        if use_uwtemplate:
            template_used = openai_underwater_template
        else:
            template_used = openai_imagenet_template
        query_features = []
        with torch.no_grad():
            for qw in query_words:
                query = self.tokenizer([temp(qw) for temp in template_used]).to(device)
                feature = self.clip.encode_text(query)
                feature /= feature.norm(dim=-1, keepdim=True)
                feature = feature.mean(dim=0)
                feature /= feature.norm()
                query_features.append(feature.unsqueeze(0))
        self.query_features = torch.cat(query_features, dim=0).detach()
# endfor ============================= Category-visual Semantic Alignment

        self.unnorm = UnNormalize([0.48145466, 0.4578275, 0.40821073], [0.26862954, 0.26130258, 0.27577711])
        self.norm = transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        self.num_queries = len(query_words)
        self.num_classes = max(self.query_idx) + 1
        self.query_idx = torch.Tensor(self.query_idx).to(torch.int64).to(device)

        self.dtype = self.query_features.dtype
        self.logit_scale = logit_scale
        self.prob_thd = prob_thd
        self.slide_stride = slide_stride
        self.slide_crop = slide_crop

        self.beta = beta
        self.gamma = gamma
        self.similarity_threshold = similarity_threshold 
        self.max_weight = max_weight

    def build_prompts_from_json(self, json_data):
        """
            eg. A photo of Fish having attributes silver, elongated, and small underwater.
        """
        prompts = []
        objects = json_data.get("Objects", [])
        attributes = json_data.get("Attributes", {})
        for obj in objects:
            obj_attr = attributes.get(obj, [])
            if obj_attr:
                if all(isinstance(sublist, list) for sublist in obj_attr):
                    sub_prompts = []
                    for idx, sublist in enumerate(obj_attr, 1):
                        attr_text = ", ".join(sublist)
                        sub_prompts.append(f"{obj}{idx} have {attr_text}")
                    prompt = ", ".join(sub_prompts)
                elif all(isinstance(sublist, dict) for sublist in obj_attr):
                    all_attrs = []
                    for d in obj_attr:
                        attr_values = [v for v in d.values() if isinstance(v, str)]
                        all_attrs.extend(attr_values)
                    attr_text = ", ".join(all_attrs)
                    prompt = f"a photo of {obj} having attributes {attr_text} underwater"
                elif isinstance(obj_attr, dict):
                    attr_values = [v for v in obj_attr.values() if isinstance(v, str)]
                    attr_text = ", ".join(attr_values)
                    prompt = f"a photo of {obj} having attributes {attr_text} underwater"
                else:
                    attr_text = ", ".join([str(a) for a in obj_attr])
                    prompt = f"a photo of {obj} having attributes {attr_text} underwater"

            else:
                prompt = f"a photo of {obj} underwater"

            prompts.append(prompt)

        return prompts
    
    def fuse_llm_reasoning_embedding(self, E1, E2):
        """
        Fuse two sets of embeddings (E1 and E2) based on cosine similarity.

        Args:
            E1 (torch.Tensor): Original embedding tensor of shape [T, C].
            E2 (torch.Tensor): Model-generated embedding tensor of shape [T2, C].
            similarity_threshold (float): Minimum cosine similarity to trigger fusion.
            max_weight (float): Maximum weight for a single fusion step.

        Returns:
            torch.Tensor: Fused embedding tensor with the same shape as E1.
        """
        # Normalize embeddings
        E1_norm = F.normalize(E1, dim=-1)
        E2_norm = F.normalize(E2, dim=-1)

        # Compute cosine similarity matrix [T2, T]
        sim_matrix = F.cosine_similarity(
            E2_norm.unsqueeze(1), E1_norm.unsqueeze(0), dim=-1
        )

        # Initialize fused embeddings
        E_fused = E1_norm.clone()
        # Fuse E1 with E2 based on similarity
        for i in range(E2.shape[0]):
            sim_val, idx = sim_matrix[i].max(dim=0)
            if sim_val >= self.similarity_threshold:
                weight = min(sim_val.item(), self.max_weight)
                E_fused[idx] = F.normalize(E_fused[idx] + weight * E2_norm[i], dim=-1)

        return E_fused
    
# endfor ============================= LLM Semantic


# ============================= Vision
    def get_geo_feats(self, x, vfm_h, vfm_w):
        geo_map, geo_feats = self.vfm(x)
        geo_feats_list = []
        for i, x in enumerate(geo_feats):
            x, cls_token = x[0], x[1]
            cls_token = cls_token.unsqueeze(1).expand_as(x)
            x = x.permute(0, 2, 1).reshape((x.shape[0], x.shape[-1], vfm_h, vfm_w))
            geo_feats_list.append(x)
        idxs = list(map(int, self.geofeats_idx.split(","))) 
        return geo_map, [geo_feats_list[i] for i in idxs] # , input_hw//14  

    @torch.no_grad()
    def forward_feature(self, img, img_path, logit_size=None):
        if type(img) == list:
            img = img[0]
        filename = os.path.basename(img_path) 

        imgs_norm = [self.norm(self.unnorm(img[i])) for i in range(len(img))]
        imgs_norm = torch.stack(imgs_norm, dim=0)
        imgs_norm = imgs_norm.half()

        # VFM feature
        if self.vfm_model == "nongeometric":
            # Forward pass in the model
            feat = self.vfm.get_intermediate_layers(imgs_norm)[0]
            nb_im = feat.shape[0]  # Batch size
            vfm_h, vfm_w = imgs_norm[0].shape[-2] // 14, imgs_norm[0].shape[-1] // 14
            vfm_feats = feat[:, 1:, :].reshape(nb_im, vfm_h, vfm_w, -1).permute(0, 3, 1, 2)
        elif self.vfm_model == "geometric":
            vfm_h, vfm_w = imgs_norm[0].shape[-2] // 14, imgs_norm[0].shape[-1] // 14
            _, vfm_feats = self.get_geo_feats(imgs_norm.half(), vfm_h, vfm_w)
        else:
            vfm_feats=None
            
        # Feature interact
        image_features = self.clip.encode_image(img.half(),
                                               external_feats=vfm_feats,
                                               beta=self.beta,
                                               gamma=self.gamma)
        image_features /= image_features.norm(dim=-1, keepdim=True)

        if self.dict_llm_embedding is not None:
            llm_reasoning_obj_embeddings = self.dict_llm_embedding[filename]["obj"]
            if llm_reasoning_obj_embeddings is not None:
                query_features_selected = F.normalize(self.fuse_llm_reasoning_embedding(self.query_features, llm_reasoning_obj_embeddings.to(self.device)), dim=-1)
            else:
                query_features_selected = self.query_features
        else:
            query_features_selected = self.query_features

        logits = image_features @ query_features_selected.T
        logits = logits.permute(0, 2, 1).reshape(-1, logits.shape[-1], vfm_h, vfm_w)

        if logit_size == None:
            logits = nn.functional.interpolate(logits, size=img.shape[-2:], mode='bilinear')
        else:
            logits = nn.functional.interpolate(logits, size=logit_size, mode='bilinear')

        return logits


    def forward_slide(self, img, img_path, img_metas, stride=112, crop_size=224):
        """Inference by sliding-window with overlap.
        If h_crop > h_img or w_crop > w_img, the small patch will be used to
        decode without padding.
        """
        if type(img) == list:
            img = img[0].unsqueeze(0)
        if type(stride) == int:
            stride = (stride, stride)
        if type(crop_size) == int:
            crop_size = (crop_size, crop_size)

        h_stride, w_stride = stride
        h_crop, w_crop = crop_size
        batch_size, _, h_img, w_img = img.shape
        out_channels = self.num_queries
        h_grids = max(h_img - h_crop + h_stride - 1, 0) // h_stride + 1
        w_grids = max(w_img - w_crop + w_stride - 1, 0) // w_stride + 1
        preds = img.new_zeros((batch_size, out_channels, h_img, w_img))
        count_mat = img.new_zeros((batch_size, 1, h_img, w_img))
        for h_idx in range(h_grids):
            for w_idx in range(w_grids):
                y1 = h_idx * h_stride
                x1 = w_idx * w_stride
                y2 = min(y1 + h_crop, h_img)
                x2 = min(x1 + w_crop, w_img)
                y1 = max(y2 - h_crop, 0)
                x1 = max(x2 - w_crop, 0)
                crop_img = img[:, :, y1:y2, x1:x2]

                # pad image when (image_size % patch_size != 0)
                H, W = crop_img.shape[2:]  # original image shape
                pad = self.compute_padsize(H, W, 56)

                if any(pad):
                    crop_img = nn.functional.pad(crop_img, pad)  # zero padding
                crop_seg_logit = self.forward_feature(crop_img, img_path).detach()

                torch.cuda.empty_cache()

                # mask cutting for padded image
                if any(pad):
                    l, t = pad[0], pad[2]
                    crop_seg_logit = crop_seg_logit[:, :, t:t + H, l:l + W]

                preds += nn.functional.pad(crop_seg_logit,
                                           (int(x1), int(preds.shape[3] - x2), int(y1),
                                            int(preds.shape[2] - y2)))

                count_mat[:, :, y1:y2, x1:x2] += 1
        assert (count_mat == 0).sum() == 0

        preds = preds / count_mat
        img_size = img_metas[0]['ori_shape'][:2]
        logits = nn.functional.interpolate(preds, size=img_size, mode='bilinear')

        return logits

    def predict(self, inputs, data_samples):
        if data_samples is not None:
            batch_img_metas = [
                data_sample.metainfo for data_sample in data_samples
            ]
        else:
            batch_img_metas = [
                                  dict(
                                      ori_shape=inputs.shape[2:],
                                      img_shape=inputs.shape[2:],
                                      pad_shape=inputs.shape[2:],
                                      padding_size=[0, 0, 0, 0])
                              ] * inputs.shape[0]

        if self.slide_crop > 0:
            seg_logits = self.forward_slide(inputs, batch_img_metas[0]['img_path'], batch_img_metas, self.slide_stride, self.slide_crop)
        else:
            seg_logits = self.forward_feature(inputs, batch_img_metas[0]['img_path'], batch_img_metas[0]['ori_shape'])

        return self.postprocess_result(seg_logits, data_samples)

    def postprocess_result(self, seg_logits, data_samples):
        batch_size = seg_logits.shape[0]
        for i in range(batch_size):
            seg_logits = seg_logits[i] * self.logit_scale
            seg_logits = seg_logits.softmax(0)  # n_queries * w * h

            num_cls, num_queries = max(self.query_idx) + 1, len(self.query_idx)
            if num_cls != num_queries:
                seg_logits = seg_logits.unsqueeze(0)
                cls_index = nn.functional.one_hot(self.query_idx)
                cls_index = cls_index.T.view(num_cls, num_queries, 1, 1)
                seg_logits = (seg_logits * cls_index).max(1)[0]

            seg_pred = seg_logits.argmax(0, keepdim=True)
            seg_pred[seg_logits.max(0, keepdim=True)[0] < self.prob_thd] = 0

            if data_samples is None:
                return seg_pred
            else:
                data_samples[i].set_data({
                    'seg_logits':
                        PixelData(**{'data': seg_logits}),
                    'pred_sem_seg':
                        PixelData(**{'data': seg_pred})
                })
        return data_samples

    def compute_padsize(self, H: int, W: int, patch_size: int):
        l, r, t, b = 0, 0, 0, 0
        if W % patch_size:
            lr = patch_size - (W % patch_size)
            l = lr // 2
            r = lr - l

        if H % patch_size:
            tb = patch_size - (H % patch_size)
            t = tb // 2
            b = tb - t

        return l, r, t, b

    def _forward(data_samples):
        """
        """

    def inference(self, img, batch_img_metas):
        """
        """

    def encode_decode(self, inputs, batch_img_metas):
        """
        """

    def extract_feat(self, inputs):
        """
        """

    def loss(self, inputs, data_samples):
        """
        """


def get_cls_idx(path):
    with open(path, 'r') as f:
        name_sets = f.readlines()
    num_cls = len(name_sets)

    class_names, class_indices = [], []
    for idx in range(num_cls):
        names_i = name_sets[idx].split('; ')
        class_names += names_i
        class_indices += [idx for _ in range(len(names_i))]
    class_names = [item.replace('\n', '') for item in class_names]
    return class_names, class_indices

