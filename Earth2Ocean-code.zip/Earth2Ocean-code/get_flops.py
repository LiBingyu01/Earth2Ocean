from Earth2Ocean import Earth2OceanSegmentation
from thop import profile
import torch

model = Earth2OceanSegmentation(clip_type='pretrained_ckpt/vitb.bin',
                                model_type='ViT-B/16',
                                name_path='configs/cls_mas3k.txt',
                                json_path='configs/llm_reasoning_AquaOV255.json',
                                imgname_list_path='configs/imglist_AquaOV255.txt',
                                # json_path='configs/llm_reasoning_AquaOV255.json',
                                # imgname_list_path='configs/imglist_AquaOV255.txt',
                                # name_path='./configs/cls_AquaOV255.txt'
                                )

input = torch.randn(1, 3, 600, 800).to('cuda')
flops, params = profile(model, inputs=(input,))
print(f"FLOPs: {flops/1e9:.2f} GFLOPs, Params: {params/1e6:.2f} M")

from ptflops import get_model_complexity_info

flops, params = get_model_complexity_info(model, (3, 600, 800), as_strings=True, print_per_layer_stat=False)
print(f"FLOPs: {flops}, Params: {params}")
