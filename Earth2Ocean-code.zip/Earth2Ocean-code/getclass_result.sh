python get_miou_maccc_class.py \
    --input_dir work_logs/AquaOV255_B\
    --json_path datasets/AquaOV255/category_split.json \
    --output_dir w_result_split/miou_macc_AquaOV255_B

python get_miou_maccc_class.py \
    --input_dir work_logs/AquaOV255_L\
    --json_path datasets/AquaOV255/category_split.json \
    --output_dir w_result_split/miou_macc_AquaOV255_L

python get_miou_maccc_class.py \
    --input_dir work_logs/AquaOV255_H\
    --json_path datasets/AquaOV255/category_split.json \
    --output_dir w_result_split/miou_macc_AquaOV255_H

