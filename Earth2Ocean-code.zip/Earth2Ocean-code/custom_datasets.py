import os.path as osp
import mmengine.fileio as fileio

from mmseg.registry import DATASETS
from mmseg.datasets import BaseSegDataset
from mmseg.registry import TRANSFORMS

import mmcv
from mmcv.transforms import LoadAnnotations as MMCV_LoadAnnotations
import warnings
import numpy as np
        


@DATASETS.register_module()
class AquaOV255(BaseSegDataset):
    """AquaOV255 dataset.

    Args:
        split (str): Split txt file for AquaOV255.
    """
    METAINFO = dict(
        classes = ( 
        "Diver", 
        "Swimmer", 
        "Geoduck", 
        "Linckialaevigata", 
        "Mantaray", 
        "Electricray", 
        "Sawfish", 
        "Bullheadshark", 
        "Greatwhiteshark", 
        "Whaleshark", 
        "Hammerheadshark", 
        "Threshershark", 
        "Seadragon", 
        "Hippocampus", 
        "Morayeel", 
        "Orbicularbatfish", 
        "Lionfish", 
        "Trumpetfish", 
        "Flounder", 
        "Frogfish", 
        "Sailfish", 
        "Enoplosusarmatus", 
        "Pseudanthiaspleurotaenia", 
        "Mola", 
        "Moorishidol", 
        "Bicolorangelfish", 
        "Atlanticspadefish", 
        "Spotteddrum", 
        "Threespotangelfish", 
        "Chromisdimidiata", 
        "Redseabannerfish", 
        "Heniochusvarius", 
        "Maldivesdamselfish", 
        "Scissortailsergeant", 
        "Firegoby", 
        "Twinspotgoby", 
        "Porcupinefish", 
        "Yellowboxfish", 
        "Blackspottedpuffer", 
        "Blueparrotfish", 
        "Stoplightparrotfish", 
        "Pomacentrussulfureus", 
        "Lunarfusilier", 
        "Ocellarisclownfish", 
        "Cinnamonclownfish", 
        "Redseaclownfish", 
        "Pinkanemonefish", 
        "Orangeskunkclownfish", 
        "Giantwrasse", 
        "Spottedwrasse", 
        "Anampsestwistii", 
        "Bluespottedwrasse", 
        "Slingjawwrasse", 
        "Redbreastedwrasse", 
        "Peacockgrouper", 
        "Potatogrouper", 
        "Graysby", 
        "Redmouthgrouper", 
        "Humpbackgrouper", 
        "Coralhind", 
        "Porkfish", 
        "Anyperodonleucogrammicus", 
        "Whitespottedsurgeonfish", 
        "Orangebandsurgeonfish", 
        "Convictsurgeonfish", 
        "Sohalsurgeonfish", 
        "Regalbluetang", 
        "Linedsurgeonfish", 
        "Achillestang", 
        "Powderbluetang", 
        "Whitecheeksurgeonfish", 
        "Saddlebutterflyfish", 
        "Mirrorbutterflyfish", 
        "Bluecheekbutterflyfish", 
        "Blacktailbutterflyfish", 
        "Raccoonbutterflyfish", 
        "Threadfinbutterflyfish", 
        "Eritreanbutterflyfish", 
        "Pyramidbutterflyfish", 
        "Copperbandbutterflyfish", 
        "Giantclams", 
        "Scallop", 
        "Abalone", 
        "Queenconch", 
        "Nautilus", 
        "Tritonstrumpet", 
        "Seaslug", 
        "Dumbooctopus", 
        "Blueringedoctopus", 
        "Commonoctopus", 
        "Squid", 
        "Cuttlefish", 
        "Seaanemone", 
        "Lionsmanejellyfish", 
        "Moonjellyfish", 
        "Friedeggjellyfish", 
        "Fancoral", 
        "Elkhorncoral", 
        "Braincoral", 
        "Seaurchin", 
        "Seacucumber", 
        "Crinoid", 
        "Oreasterreticulatus", 
        "Protoreasternodosus", 
        "Killerwhale", 
        "Spermwhale", 
        "Humpbackwhale", 
        "Seal", 
        "Manatee", 
        "Sealion", 
        "Dolphin", 
        "Walrus", 
        "Dugong", 
        "Turtle", 
        "Snake", 
        "Homarus", 
        "Spinylobster", 
        "Commonprawn", 
        "Mantisshrimp", 
        "Kingcrab", 
        "Hermitcrab", 
        "Cancerpagurus", 
        "Swimmingcrab", 
        "Spannercrab", 
        "Penguin", 
        "Sponge", 
        "Plasticbag", 
        "Plasticbottle", 
        "Plasticcup", 
        "Plasticbox", 
        "Glassbottle", 
        "Surgicalmask", 
        "Tyre", 
        "Can", 
        "Shipwreck", 
        "Wreckedaircraft", 
        "Wreckedcar", 
        "Wreckedtank", 
        "Gun", 
        "Phone", 
        "Ring", 
        "Boots", 
        "Glasses", 
        "Coin", 
        "Statue", 
        "Amphora", 
        "Anchor", 
        "Shipswheel", 
        "Auv", 
        "Rov", 
        "Militarysubmarines", 
        "Personalsubmarines", 
        "Shipsanode", 
        "Overboardvalve", 
        "Propeller", 
        "Seachestgrating", 
        "Submarinepipeline", 
        "Pipelinesanode", 
        "Alligatorgar", 
        "Archerfish", 
        "Arowana", 
        "Banggaicardinalfish", 
        "Barreleyefish", 
        "Baskingshark", 
        "Bigheadcarp", 
        "Blackcarp", 
        "Blanketoctopus", 
        "Bluegill", 
        "Bubblecoral", 
        "Burbot", 
        "Carpsucker", 
        "Catfish", 
        "Chimaera", 
        "Christmastreeworm", 
        "Cleanershrimp", 
        "Clownloach", 
        "Coconutcrab", 
        "Commoncarp", 
        "Conesnail", 
        "Convictcichlid", 
        "Copepod", 
        "Coralshrimp", 
        "Crappie", 
        "Crocodile&alligator", 
        "Cruciancarp", 
        "Cushionstar", 
        "Deepseahatchetfish", 
        "Discusfish", 
        "Fangblenny", 
        "Fangtooth", 
        "Filefish", 
        "Flamingotonguesnail", 
        "Flashlightfish", 
        "Flatworm", 
        "Frilledshark", 
        "Gardeneel", 
        "Giantgourami", 
        "Goblinshark", 
        "Goldfish", 
        "Grasscarp", 
        "Grayling", 
        "Guppy", 
        "Horseshoecrab", 
        "Killifish", 
        "Koi", 
        "Kuhliloach", 
        "Lanternfish", 
        "Largemouthbass", 
        "Leafscorpionfish", 
        "Leafyseadragon", 
        "Mandarinfish", 
        "Marineiguana", 
        "Mimicoctopus", 
        "Mudskipper", 
        "Neontetra", 
        "Oarfish", 
        "Oscarfish", 
        "Paddlefish", 
        "Pearlgourami", 
        "Perch", 
        "Pike", 
        "Pilotfish", 
        "Pineconefish", 
        "Pompomcrab", 
        "Pomacanthusfish", 
        "Pygmyseahorse", 
        "Remora", 
        "Ribboneel", 
        "Rosybarb", 
        "Salmon", 
        "Sanddollar", 
        "Seaangel", 
        "Seaapple", 
        "Seapig", 
        "Seaspider", 
        "Seasquirt", 
        "Silvercarp", 
        "Smallmouthbass", 
        "Snakeheadfish", 
        "Snowcrab", 
        "Spanishdancernudibranch", 
        "Spidercrab", 
        "Spottedgar", 
        "Sturgeon", 
        "Swordtail", 
        "Tigerbarb", 
        "Tilapia", 
        "Triggerfish", 
        "Tripodspiderfish", 
        "Trout", 
        "Velvetbellylanternshark", 
        "Weatherloach", 
        "Wobbegong", 
        "Zebrafish"),
        palette = [[255, 0, 0], [0, 255, 0], [0, 0, 255], [255, 255, 0], [255, 0, 255], [0, 255, 255], 
                   [128, 0, 0], [0, 128, 0], [0, 0, 128], [128, 128, 0], [128, 0, 128], [0, 128, 128], 
                   [192, 0, 0], [0, 192, 0], [0, 0, 192], [192, 192, 0], [192, 0, 192], [0, 192, 192], 
                   [64, 0, 0], [0, 64, 0], [0, 0, 64], [64, 64, 0], [64, 0, 64], [0, 64, 64], [255, 128, 0], 
                   [255, 0, 128], [128, 255, 0], [0, 255, 128], [128, 0, 255], [0, 128, 255], [255, 64, 0], 
                   [255, 0, 64], [64, 255, 0], [0, 255, 64], [64, 0, 255], [0, 64, 255], [255, 128, 128], 
                   [128, 255, 128], [128, 128, 255], [255, 64, 128], [64, 255, 128], [128, 255, 64], [192, 128, 64], 
                   [128, 192, 64], [64, 128, 192], [192, 64, 128], [64, 192, 128], [128, 64, 192], [255, 128, 64], 
                   [64, 128, 255], [255, 192, 64], [192, 255, 64], [64, 255, 192], [192, 64, 255], [64, 192, 255], 
                   [255, 64, 192], [255, 192, 128], [192, 255, 128], [128, 255, 192], [255, 128, 192], [192, 128, 255], 
                   [128, 192, 255], [255, 255, 128], [255, 128, 255], [128, 255, 255], [255, 255, 64], [255, 64, 255],
                    [64, 255, 255], [255, 64, 64], [64, 255, 64], [64, 64, 255], [192, 255, 255], [255, 192, 255], 
                    [255, 255, 192], [64, 128, 64], [128, 64, 64], [64, 64, 128], [128, 64, 128],
                      [64, 128, 128], [192, 128, 128], [128, 192, 128], [128, 128, 192], [192, 64, 64], 
                      [64, 192, 64], [64, 64, 192], [255, 160, 0], [0, 160, 255], [160, 255, 0], [255, 0, 160],
                        [160, 0, 255], [0, 255, 160], [255, 96, 0], [0, 96, 255], [96, 255, 0], [255, 0, 96],
                          [96, 0, 255], [0, 255, 96], [255, 224, 0], [0, 224, 255], [224, 255, 0], [255, 0, 224], [224, 0, 255],
                            [0, 255, 224], [96, 96, 96], [160, 160, 160], [224, 224, 224], [32, 32, 32], [64, 64, 64], 
                            [96, 40, 96], [128, 128, 128], [40, 160, 160], [192, 192, 192], [224, 45, 224], [255, 255, 255], [15, 34, 35], 
                            [255, 200, 0], [200, 255, 0], [0, 255, 200], [0, 200, 255], [200, 0, 255], [255, 0, 200], [255, 150, 50], 
                            [150, 255, 50], [50, 150, 255], [255, 50, 150], [50, 255, 150], [150, 50, 255], [200, 50, 100], [100, 200, 50], 
                            [50, 100, 200], [255, 100, 50], [100, 255, 50], [50, 255, 100], [255, 50, 100], [100, 50, 255], [255, 100, 200], 
                            [200, 255, 100], [100, 200, 255], [255, 200, 100], [200, 100, 255], [100, 255, 200], [240, 80, 40], [80, 240, 40], 
                            [40, 80, 240], [240, 40, 80], [80, 40, 240], [40, 240, 80], [240, 160, 80], [160, 240, 80], [80, 160, 240], 
                            [240, 80, 160], [160, 80, 240], [80, 240, 160], [255, 180, 90], [180, 255, 90], [90, 180, 255], [255, 90, 180], 
                            [90, 255, 180], [180, 90, 255], [220, 130, 220], [130, 220, 220], [220, 220, 130], [180, 255, 255], [255, 180, 255], 
                            [255, 255, 180], [100, 255, 255], [255, 100, 255], [255, 255, 100], [180, 180, 255], [180, 255, 180], [255, 180, 180], 
                            [64, 200, 255], [200, 64, 255], [255, 200, 64], [29, 205, 91], [97, 185, 159], [70, 108, 41], [200, 255, 200], 
                            [255, 200, 200], [200, 200, 255], [150, 255, 255], [255, 150, 255], [255, 255, 150], [100, 100, 255], 
                            [100, 255, 100], [255, 100, 100], [80, 255, 160], [160, 80, 255], [255, 160, 80], [140, 255, 200], [200, 140, 255], 
                            [255, 200, 140], [24, 106, 35], [145, 170, 47], [157, 41, 86], [255, 220, 160], [220, 160, 255], 
                            [160, 255, 220], [214, 89, 82], [223, 253, 37], [61, 193, 3], [210, 90, 180], [90, 210, 180], 
                            [180, 210, 90], [210, 120, 120], [120, 210, 120], [120, 120, 210], [210, 210, 120], [210, 120, 210],
                              [120, 210, 210], [150, 210, 150], [210, 150, 150], [150, 150, 210], [240, 180, 120], [180, 240, 120],
                                [120, 180, 240], [240, 120, 180], [180, 120, 240], [120, 240, 180], [75, 180, 220], [180, 75, 220], 
                                [220, 75, 180], [220, 180, 75], [75, 220, 180], [180, 220, 75], [110, 140, 250], [250, 110, 140], 
                                [140, 250, 110], [90, 250, 190], [250, 90, 190], [190, 250, 90], [220, 180, 220], [180, 220, 180], 
                                [180, 180, 220], [60, 160, 240], [240, 60, 160], [160, 240, 60], [255, 220, 90], [90, 255, 220], 
                                [220, 90, 255], [255, 180, 210], [210, 255, 180], [180, 210, 255], [255, 140, 100], [100, 255, 140], 
                                [140, 100, 255], [200, 160, 220], [220, 200, 160], [160, 220, 200], [255, 200, 180], [180, 255, 200], 
                                [200, 180, 255], [255, 240, 200], [200, 255, 240]])

    def __init__(self, **kwargs):
        super(AquaOV255, self).__init__(img_suffix='.jpg', seg_map_suffix='.png', **kwargs)
        
@DATASETS.register_module()
class SUIMTRAINVALDataset(BaseSegDataset):
    """SUIMTRAINVALDataset dataset.

    Args:
        split (str): Split txt file for SUIMTRAINVALDataset.
    """
    METAINFO = dict(
        classes = (
                "Robots/instruments",
                "Plants/sea-grass",
                "Fish and vertebrates",
                "Human divers",
                "Reefs and invertebrates",
                "Wrecks/ruins",
                "Sand/sea-floor (& rocks)",),
        palette = [[255, 0, 0], [0, 255, 0], [0, 0, 255], [255, 255, 0], [255, 0, 255],
                    [0, 255, 255], [128, 0, 0]])

    def __init__(self, **kwargs):
        super(SUIMTRAINVALDataset, self).__init__(img_suffix='.png', seg_map_suffix='.png', **kwargs)


@DATASETS.register_module()
class MAS3K(BaseSegDataset):
    """MAS3K dataset.

    Args:
        split (str): Split txt file for MAS3K.
    """
    METAINFO = dict(
        classes = (
            "AngelFish",
            "BatFish",
            "Butterflyfish",
            "ClownFish",
            "Conch",
            "Crab",
            "CrocodileFish",
            "CuttleFish",
            "Dolphin",
            "ElectricRay",
            "Fish",
            "Flounder",
            "FrogFish",
            "GhostPipeFish",
            "Grouper",
            "JellyFish",
            "LeafySeaDragon",
            "LionFish",
            "MantaRay",
            "MorayEel",
            "Octopus",
            "Pagurian",
            "PipeFish",
            "Piranha",
            "RatFish",
            "ScorpionFish",
            "SeaCucumber",
            "SeaHorse",
            "Seal",
            "Shark",
            "Shrimp",
            "Slug",
            "StarFish",
            "Stingaree",
            "SurgeonFish",
            "TriggerFish",
            "Turtle"),
        palette = [[255, 0, 0], [0, 255, 0], [0, 0, 255], [255, 255, 0], [255, 0, 255],
                    [0, 255, 255], [128, 0, 0], [0, 128, 0], [0, 0, 128], [128, 128, 0],
                    [128, 0, 128], [0, 128, 128], [192, 0, 0], [0, 192, 0], [0, 0, 192],
                    [192, 192, 0], [192, 0, 192], [0, 192, 192], [64, 0, 0], [0, 64, 0],
                    [0, 0, 64], [64, 64, 0], [64, 0, 64], [0, 64, 64], [255, 128, 0],
                    [255, 0, 128], [128, 255, 0], [0, 255, 128], [128, 0, 255], [0, 128, 255],
                    [255, 64, 0], [255, 0, 64], [64, 255, 0], [0, 255, 64], [64, 0, 255],
                    [0, 64, 255], [255, 192, 0]])

    def __init__(self, **kwargs):
        super(MAS3K, self).__init__(img_suffix='.jpg', seg_map_suffix='.png', **kwargs)


@DATASETS.register_module()
class DUTUSEGDataset(BaseSegDataset):
    """DUTUSEGDataset dataset.

    Args:
        split (str): Split txt file for DUTUSEGDataset.
    """
    METAINFO = dict(
        classes = ("holothurian", "echinus", "scallop", "starfish",),
        palette = [[255, 0, 0], [0, 255, 0], [0, 0, 255], [255, 255, 0]])

    def __init__(self, **kwargs):
        super(DUTUSEGDataset, self).__init__(img_suffix='.jpg', seg_map_suffix='.png', **kwargs)

@DATASETS.register_module()
class USIS10KVALTESTDataset(BaseSegDataset):
    """USIS10KVALTESTDataset dataset.

    Args:
        split (str): Split txt file for USIS10KVALTESTDataset.
    """
    METAINFO = dict(
        classes = ("wrecks/ruins",
                    "fish",
                    "reefs",
                    "aquatic plants",
                    "human divers",
                    "robots",
                    "sea-floor"),
        palette = [[255, 0, 0], [0, 255, 0], [0, 0, 255], [255, 255, 0], [255, 0, 255],
                    [0, 255, 255], [128, 0, 0],])

    def __init__(self, **kwargs):
        super(USIS10KVALTESTDataset, self).__init__(img_suffix='.jpg', seg_map_suffix='.png', **kwargs)


@DATASETS.register_module()
class USIS16K(BaseSegDataset):
    """USIS16K dataset.

    Args:
        split (str): Split txt file for USIS16K.
    """
    METAINFO = dict(
        classes = (
        "Diver", 
        "Swimmer", 
        "Geoduck", 
        "Linckia laevigata", 
        "Manta ray", 
        "Electric ray",
        "Sawfish", 
        "Bullhead shark", 
        "Great White shark", 
        "Whale shark", 
        "Hammerhead shark", 
        "Thresher shark",
        "Sea dragon", 
        "Hippocampus", 
        "Moray eel", 
        "Orbicular batfish", 
        "Lionfish", 
        "Trumpetfish",
        "Flounder", 
        "Frogfish", 
        "Sailfish", 
        "Enoplosus armatus", 
        "Pseudanthias pleurotaenia", 
        "Mola",
        "Moorish idol", 
        "Bicolor angelfish", 
        "Atlantic spadefish", 
        "Spotted drum", 
        "Threespot angelfish", 
        "Chromis dimidiata",
        "Redsea bannerfish", 
        "Heniochus varius", 
        "Maldives damselfish", 
        "Scissortail sergeant", 
        "Fire goby", 
        "Twin-spot goby",
        "Porcupinefish", 
        "Yellow boxfish", 
        "Blackspotted puffer", 
        "Blue parrotfish", 
        "Stoplight parrotfish", 
        "Pomacentrus sulfureus",
        "Lunar fusilier", 
        "Ocellaris clownfish", 
        "Cinnamon clownfish", 
        "Red Sea clownfish", 
        "Pink anemonefish", 
        "Orange skunk clownfish",
        "Giant wrasse", 
        "Spotted wrasse", 
        "Anampses twistii", 
        "Blue-spotted wrasse", 
        "Slingjaw wrasse", 
        "Red-breasted wrasse",
        "Peacock grouper", 
        "Potato grouper", 
        "Graysby", 
        "Redmouth grouper", 
        "Humpback grouper", 
        "Coral hind",
        "Porkfish", 
        "Anyperodon leucogrammicus", 
        "Whitespotted surgeonfish", 
        "Orange-band surgeonfish", 
        "Convict surgeonfish", 
        "Sohal surgeonfish",
        "Regal blue tang", 
        "Lined surgeonfish", 
        "Achilles tang", 
        "Powder blue tang", 
        "Whitecheek surgeonfish", 
        "Saddle butterflyfish",
        "Mirror butterflyfish", 
        "Bluecheek butterflyfish", 
        "Blacktail butterflyfish", 
        "Raccoon butterflyfish", 
        "Threadfinbutterflyfish", 
        "Eritrean butterflyfish",
        "Pyramid butterflyfish", 
        "Copperband butterflyfish", 
        "Giant clams", 
        "Scallop", 
        "Abalone", 
        "Queen conch",
        "Nautilus", 
        "Triton's trumpet", 
        "Sea Slug", 
        "Dumbo octopus", 
        "Blue-ringedoctopus", 
        "Common octopus",
        "Squid", 
        "Cuttlefish", 
        "Sea anemone", 
        "Lion's mane jellyfish", 
        "Moon jellyfish",
        "Fried egg jellyfish",
        "Fan coral", 
        "Elkhorn coral", 
        "Brain coral", 
        "Sea urchin",
        "Sea cucumber", 
        "Crinoid",
        "Oreaster reticulatus", 
        "Protoreaster nodosus", 
        "Killer whale", 
        "Sperm whale", 
        "Humpback whale", 
        "Seal",
        "Manatee", 
        "Sea lion", 
        "Dolphin", 
        "Walrus", 
        "Dugong", 
        "Turtle",
        "Snake", 
        "Homarus", 
        "Spiny lobster", 
        "Common prawn", 
        "Mantis shrimp",
        "King crab",
        "Hermit crab", 
        "Cancer pagurus", 
        "Swimming crab", 
        "Spanner crab", 
        "Penguin", 
        "Sponge",
        "Plastic bag", 
        "Plastic bottle", 
        "Plastic cup", 
        "Plastic box", 
        "Glass bottle", 
        "Surgical mask",
        "Tyre", 
        "Can", 
        "Shipwreck", 
        "Wrecked aircraft", 
        "Wrecked car", 
        "Wrecked tank",
        "Gun", 
        "Phone", 
        "Ring", 
        "Boots", 
        "Glasses",
        "Coin",
        "Statue", 
        "Amphora", 
        "Anchor", 
        "Ship's Wheel", 
        "Autonomous underwater vehicle (AUV)", 
        "Remotely operated vehicle (ROV)",
        "Military submarines", 
        "Personal submarines", 
        "Ship's anode", 
        "Over board valve", 
        "Propeller", 
        "Sea chest grating",
        "Submarine pipeline", 
        "Pipeline's anode"),
        palette = [
                    [255, 0, 0], [0, 255, 0], [0, 0, 255], [255, 255, 0], [255, 0, 255],
                    [0, 255, 255], [128, 0, 0], [0, 128, 0], [0, 0, 128], [128, 128, 0],
                    [128, 0, 128], [0, 128, 128], [192, 0, 0], [0, 192, 0], [0, 0, 192],
                    [192, 192, 0], [192, 0, 192], [0, 192, 192], [64, 0, 0], [0, 64, 0],
                    [0, 0, 64], [64, 64, 0], [64, 0, 64], [0, 64, 64], [255, 128, 0],
                    [255, 0, 128], [128, 255, 0], [0, 255, 128], [128, 0, 255], [0, 128, 255],
                    [255, 64, 0], [255, 0, 64], [64, 255, 0], [0, 255, 64], [64, 0, 255],
                    [0, 64, 255], [255, 192, 0], [255, 0, 192], [192, 255, 0], [0, 255, 192],
                    [192, 0, 255], [0, 192, 255], [128, 64, 0], [128, 0, 64], [64, 128, 0],
                    [0, 128, 64], [64, 0, 128], [0, 64, 128], [255, 255, 128], [255, 128, 255],
                    [128, 255, 255], [255, 128, 128], [128, 255, 128], [128, 128, 255], [255, 64, 128],
                    [128, 64, 255], [64, 128, 255], [64, 255, 128], [128, 255, 64], [255, 128, 64],
                    [192, 64, 0], [192, 0, 64], [64, 192, 0], [0, 192, 64], [64, 0, 192],
                    [0, 64, 192], [192, 128, 0], [192, 0, 128], [128, 192, 0], [0, 192, 128],
                    [128, 0, 192], [0, 128, 192], [192, 64, 128], [128, 64, 192], [64, 192, 128],
                    [64, 128, 192], [128, 192, 64], [192, 128, 64], [255, 192, 64], [192, 255, 64],
                    [17, 100, 60], [101, 230, 195], [230, 222, 163], [116, 140, 146], [34, 184, 92],
                    [52, 46, 241], [128, 138, 10], [133, 120, 39], [34, 212, 240], [251, 202, 202],
                    [209, 69, 192], [193, 6, 44], [153, 63, 18], [237, 54, 96], [158, 183, 109],
                    [63, 156, 226], [5, 27, 48], [142, 142, 165], [92, 85, 9], [58, 73, 38],
                    [205, 207, 4], [98, 221, 109], [191, 232, 250], [199, 155, 140], [97, 165, 57],
                    [76, 242, 238], [93, 206, 247], [102, 160, 133], [62, 213, 175], [69, 93, 203],
                    [245, 95, 53], [28, 51, 88], [198, 245, 70], [21, 119, 187], [241, 56, 102],
                    [193, 239, 38], [10, 106, 191], [51, 21, 76], [86, 98, 246], [56, 20, 155],
                    [0, 196, 214], [94, 175, 14], [31, 97, 216], [24, 30, 177], [2, 204, 158],
                    [5, 214, 252], [9, 64, 12], [166, 189, 121], [129, 25, 8], [53, 114, 0],
                    [83, 49, 65], [51, 181, 44], [57, 112, 184], [252, 88, 148], [86, 5, 179],
                    [198, 144, 220], [188, 77, 97], [248, 240, 45], [127, 245, 183], [118, 73, 129],
                    [248, 191, 96], [4, 245, 60], [215, 9, 173], [151, 16, 216], [248, 56, 200],
                    [34, 6, 104], [11, 91, 206], [0, 143, 25], [239, 63, 228], [153, 236, 17],
                    [28, 135, 172], [215, 83, 4], [162, 70, 182], [8, 177, 233], [87, 8, 70],
                    [54, 92, 117], [206, 15, 125], [10, 246, 2]
                ])

    def __init__(self, **kwargs):
        super(USIS16K, self).__init__(img_suffix='.jpg', seg_map_suffix='.png', **kwargs)


@DATASETS.register_module()
class PascalVOC20Dataset(BaseSegDataset):
    """Pascal VOC dataset.

    Args:
        split (str): Split txt file for Pascal VOC.
    """
    METAINFO = dict(
        classes=('aeroplane', 'bicycle', 'bird', 'boat',
                 'bottle', 'bus', 'car', 'cat', 'chair', 'cow', 'diningtable',
                 'dog', 'horse', 'motorbike', 'person', 'pottedplant', 'sheep',
                 'sofa', 'train', 'tvmonitor'),
        palette=[[128, 0, 0], [0, 128, 0], [0, 0, 192],
                 [128, 128, 0], [128, 0, 128], [0, 128, 128], [192, 128, 64],
                 [64, 0, 0], [192, 0, 0], [64, 128, 0], [192, 128, 0],
                 [64, 0, 128], [192, 0, 128], [64, 128, 128], [192, 128, 128],
                 [0, 64, 0], [128, 64, 0], [0, 192, 0], [128, 192, 0],
                 [0, 64, 128]])

    def __init__(self,
                 ann_file,
                 img_suffix='.jpg',
                 seg_map_suffix='.png',
                 reduce_zero_label=True,
                 **kwargs) -> None:
        super().__init__(
            img_suffix=img_suffix,
            seg_map_suffix=seg_map_suffix,
            reduce_zero_label=reduce_zero_label,
            ann_file=ann_file,
            **kwargs)
        assert fileio.exists(self.data_prefix['img_path'],
                             self.backend_args) and osp.isfile(self.ann_file)


@DATASETS.register_module()
class COCOObjectDataset(BaseSegDataset):
    """
    Implementation borrowed from TCL (https://github.com/kakaobrain/tcl) and GroupViT (https://github.com/NVlabs/GroupViT)
    COCO-Object dataset.
    1 bg class + first 80 classes from the COCO-Stuff dataset.
    """

    METAINFO = dict(

        classes=('background', 'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck', 'boat',
                 'traffic light', 'fire hydrant', 'stop sign', 'parking meter', 'bench', 'bird', 'cat', 'dog', 'horse',
                 'sheep', 'cow', 'elephant', 'bear', 'zebra', 'giraffe', 'backpack', 'umbrella', 'handbag', 'tie',
                 'suitcase', 'frisbee', 'skis', 'snowboard', 'sports ball', 'kite', 'baseball bat', 'baseball glove',
                 'skateboard', 'surfboard', 'tennis racket', 'bottle', 'wine glass', 'cup', 'fork', 'knife', 'spoon',
                 'bowl', 'banana', 'apple', 'sandwich', 'orange', 'broccoli', 'carrot', 'hot dog', 'pizza', 'donut',
                 'cake', 'chair', 'couch', 'potted plant', 'bed', 'dining table', 'toilet', 'tv', 'laptop', 'mouse',
                 'remote', 'keyboard', 'cell phone', 'microwave', 'oven', 'toaster', 'sink', 'refrigerator', 'book',
                 'clock', 'vase', 'scissors', 'teddy bear', 'hair drier', 'toothbrush'),

        palette=[[0, 0, 0], [0, 192, 64], [0, 192, 64], [0, 64, 96], [128, 192, 192], [0, 64, 64], [0, 192, 224],
                 [0, 192, 192], [128, 192, 64], [0, 192, 96], [128, 192, 64], [128, 32, 192], [0, 0, 224], [0, 0, 64],
                 [0, 160, 192], [128, 0, 96], [128, 0, 192], [0, 32, 192], [128, 128, 224], [0, 0, 192],
                 [128, 160, 192],
                 [128, 128, 0], [128, 0, 32], [128, 32, 0], [128, 0, 128], [64, 128, 32], [0, 160, 0], [0, 0, 0],
                 [192, 128, 160], [0, 32, 0], [0, 128, 128], [64, 128, 160], [128, 160, 0], [0, 128, 0], [192, 128, 32],
                 [128, 96, 128], [0, 0, 128], [64, 0, 32], [0, 224, 128], [128, 0, 0], [192, 0, 160], [0, 96, 128],
                 [128, 128, 128], [64, 0, 160], [128, 224, 128], [128, 128, 64], [192, 0, 32],
                 [128, 96, 0], [128, 0, 192], [0, 128, 32], [64, 224, 0], [0, 0, 64], [128, 128, 160], [64, 96, 0],
                 [0, 128, 192], [0, 128, 160], [192, 224, 0], [0, 128, 64], [128, 128, 32], [192, 32, 128],
                 [0, 64, 192],
                 [0, 0, 32], [64, 160, 128], [128, 64, 64], [128, 0, 160], [64, 32, 128], [128, 192, 192], [0, 0, 160],
                 [192, 160, 128], [128, 192, 0], [128, 0, 96], [192, 32, 0], [128, 64, 128], [64, 128, 96],
                 [64, 160, 0],
                 [0, 64, 0], [192, 128, 224], [64, 32, 0], [0, 192, 128], [64, 128, 224], [192, 160, 0]])

    def __init__(self, **kwargs):
        super(COCOObjectDataset, self).__init__(img_suffix='.jpg', seg_map_suffix='_instanceTrainIds.png', **kwargs)


@DATASETS.register_module()
class PascalContext60Dataset(BaseSegDataset):
    METAINFO = dict(
        classes=('background', 'aeroplane', 'bag', 'bed', 'bedclothes',
                 'bench', 'bicycle', 'bird', 'boat', 'book', 'bottle',
                 'building', 'bus', 'cabinet', 'car', 'cat', 'ceiling',
                 'chair', 'cloth', 'computer', 'cow', 'cup', 'curtain', 'dog',
                 'door', 'fence', 'floor', 'flower', 'food', 'grass', 'ground',
                 'horse', 'keyboard', 'light', 'motorbike', 'mountain',
                 'mouse', 'person', 'plate', 'platform', 'pottedplant', 'road',
                 'rock', 'sheep', 'shelves', 'sidewalk', 'sign', 'sky', 'snow',
                 'sofa', 'table', 'track', 'train', 'tree', 'truck',
                 'tvmonitor', 'wall', 'water', 'window', 'wood'),
        palette=[[120, 120, 120], [180, 120, 120], [6, 230, 230], [80, 50, 50],
                 [4, 200, 3], [120, 120, 80], [140, 140, 140], [204, 5, 255],
                 [230, 230, 230], [4, 250, 7], [224, 5, 255], [235, 255, 7],
                 [150, 5, 61], [120, 120, 70], [8, 255, 51], [255, 6, 82],
                 [143, 255, 140], [204, 255, 4], [255, 51, 7], [204, 70, 3],
                 [0, 102, 200], [61, 230, 250], [255, 6, 51], [11, 102, 255],
                 [255, 7, 71], [255, 9, 224], [9, 7, 230], [220, 220, 220],
                 [255, 9, 92], [112, 9, 255], [8, 255, 214], [7, 255, 224],
                 [255, 184, 6], [10, 255, 71], [255, 41, 10], [7, 255, 255],
                 [224, 255, 8], [102, 8, 255], [255, 61, 6], [255, 194, 7],
                 [255, 122, 8], [0, 255, 20], [255, 8, 41], [255, 5, 153],
                 [6, 51, 255], [235, 12, 255], [160, 150, 20], [0, 163, 255],
                 [140, 140, 140], [250, 10, 15], [20, 255, 0], [31, 255, 0],
                 [255, 31, 0], [255, 224, 0], [153, 255, 0], [0, 0, 255],
                 [255, 71, 0], [0, 235, 255], [0, 173, 255], [31, 0, 255]])

    def __init__(self,
                 ann_file: str,
                 img_suffix='.jpg',
                 seg_map_suffix='.png',
                 **kwargs) -> None:
        super().__init__(
            img_suffix=img_suffix,
            seg_map_suffix=seg_map_suffix,
            ann_file=ann_file,
            reduce_zero_label=False,
            **kwargs)


@DATASETS.register_module()
class PascalContext59Dataset(BaseSegDataset):
    METAINFO = dict(
        classes=('aeroplane', 'bag', 'bed', 'bedclothes', 'bench', 'bicycle',
                 'bird', 'boat', 'book', 'bottle', 'building', 'bus',
                 'cabinet', 'car', 'cat', 'ceiling', 'chair', 'cloth',
                 'computer', 'cow', 'cup', 'curtain', 'dog', 'door', 'fence',
                 'floor', 'flower', 'food', 'grass', 'ground', 'horse',
                 'keyboard', 'light', 'motorbike', 'mountain', 'mouse',
                 'person', 'plate', 'platform', 'pottedplant', 'road', 'rock',
                 'sheep', 'shelves', 'sidewalk', 'sign', 'sky', 'snow', 'sofa',
                 'table', 'track', 'train', 'tree', 'truck', 'tvmonitor',
                 'wall', 'water', 'window', 'wood'),
        palette=[[180, 120, 120], [6, 230, 230], [80, 50, 50], [4, 200, 3],
                 [120, 120, 80], [140, 140, 140], [204, 5, 255],
                 [230, 230, 230], [4, 250, 7], [224, 5, 255], [235, 255, 7],
                 [150, 5, 61], [120, 120, 70], [8, 255, 51], [255, 6, 82],
                 [143, 255, 140], [204, 255, 4], [255, 51, 7], [204, 70, 3],
                 [0, 102, 200], [61, 230, 250], [255, 6, 51], [11, 102, 255],
                 [255, 7, 71], [255, 9, 224], [9, 7, 230], [220, 220, 220],
                 [255, 9, 92], [112, 9, 255], [8, 255, 214], [7, 255, 224],
                 [255, 184, 6], [10, 255, 71], [255, 41, 10], [7, 255, 255],
                 [224, 255, 8], [102, 8, 255], [255, 61, 6], [255, 194, 7],
                 [255, 122, 8], [0, 255, 20], [255, 8, 41], [255, 5, 153],
                 [6, 51, 255], [235, 12, 255], [160, 150, 20], [0, 163, 255],
                 [140, 140, 140], [250, 10, 15], [20, 255, 0], [31, 255, 0],
                 [255, 31, 0], [255, 224, 0], [153, 255, 0], [0, 0, 255],
                 [255, 71, 0], [0, 235, 255], [0, 173, 255], [31, 0, 255]])

    def __init__(self,
                 ann_file: str,
                 img_suffix='.jpg',
                 seg_map_suffix='.png',
                 reduce_zero_label=True,
                 **kwargs):
        super().__init__(
            img_suffix=img_suffix,
            seg_map_suffix=seg_map_suffix,
            ann_file=ann_file,
            reduce_zero_label=reduce_zero_label,
            **kwargs)

@DATASETS.register_module()
class ADE20K847Dataset(BaseSegDataset):
    """Pascal VOC dataset.

    Args:
        split (str): Split txt file for Pascal VOC.
    """
    METAINFO = dict(
        classes=("wall", "building, edifice", "sky", "tree", "road, route", "floor, flooring", "ceiling", "bed", "sidewalk, pavement", "earth, ground", "cabinet", "person, individual, someone, somebody, mortal, soul", "grass", "windowpane, window", "car, auto, automobile, machine, motorcar", "mountain, mount", "plant, flora, plant life", "table", "chair", "curtain, drape, drapery, mantle, pall", "door", "sofa, couch, lounge", "sea", "painting, picture", "water", "mirror", "house", "rug, carpet, carpeting", "shelf", "armchair", "fence, fencing", "field", "lamp", "rock, stone", "seat", "river", "desk", "bathtub, bathing tub, bath, tub", "railing, rail", "signboard, sign", "cushion", "path", "work surface", "stairs, steps", "column, pillar", "sink", "wardrobe, closet, press", "snow", "refrigerator, icebox", "base, pedestal, stand", "bridge, span", "blind, screen", "runway", "cliff, drop, drop-off", "sand", "fireplace, hearth, open fireplace", "pillow", "screen door, screen", "toilet, can, commode, crapper, pot, potty, stool, throne", "skyscraper", "grandstand, covered stand", "box", "pool table, billiard table, snooker table", "palm, palm tree", "double door", "coffee table, cocktail table", "counter", "countertop", "chest of drawers, chest, bureau, dresser", "kitchen island", "boat", "waterfall, falls", "stove, kitchen stove, range, kitchen range, cooking stove", "flower", "bookcase", "controls", "book", "stairway, staircase", "streetlight, street lamp", "computer, computing machine, computing device, data processor, electronic computer, information processing system", "bus, autobus, coach, charabanc, double-decker, jitney, motorbus, motorcoach, omnibus, passenger vehicle", "swivel chair", "light, light source", "bench", "case, display case, showcase, vitrine", "towel", "fountain", "embankment", "television receiver, television, television set, tv, tv set, idiot box, boob tube, telly, goggle box", "van", "hill", "awning, sunshade, sunblind", "poster, posting, placard, notice, bill, card", "truck, motortruck", "airplane, aeroplane, plane", "pole", "tower", "court", "ball", "aircraft carrier, carrier, flattop, attack aircraft carrier", "buffet, counter, sideboard", "hovel, hut, hutch, shack, shanty", "apparel, wearing apparel, dress, clothes", "minibike, motorbike", "animal, animate being, beast, brute, creature, fauna", "chandelier, pendant, pendent", "step, stair", "booth, cubicle, stall, kiosk", "bicycle, bike, wheel, cycle", "doorframe, doorcase", "sconce", "pond", "trade name, brand name, brand, marque", "bannister, banister, balustrade, balusters, handrail", "bag", "traffic light, traffic signal, stoplight", "gazebo", "escalator, moving staircase, moving stairway", "land, ground, soil", "board, plank", "arcade machine", "eiderdown, duvet, continental quilt", "bar", "stall, stand, sales booth", "playground", "ship", "ottoman, pouf, pouffe, puff, hassock", "ashcan, trash can, garbage can, wastebin, ash bin, ash-bin, ashbin, dustbin, trash barrel, trash bin", "bottle", "cradle", "pot, flowerpot", "conveyer belt, conveyor belt, conveyer, conveyor, transporter", "train, railroad train", "stool", "lake", "tank, storage tank", "ice, water ice", "basket, handbasket", "manhole", "tent, collapsible shelter", "canopy", "microwave, microwave oven", "barrel, cask", "dirt track", "beam", "dishwasher, dish washer, dishwashing machine", "plate", "screen, crt screen", "ruins", "washer, automatic washer, washing machine", "blanket, cover", "plaything, toy", "food, solid food", "screen, silver screen, projection screen", "oven", "stage", "beacon, lighthouse, beacon light, pharos", "umbrella", "sculpture", "aqueduct", "container", "scaffolding, staging", "hood, exhaust hood", "curb, curbing, kerb", "roller coaster", "horse, equus caballus", "catwalk", "glass, drinking glass", "vase", "central reservation", "carousel", "radiator", "closet", "machine", "pier, wharf, wharfage, dock", "fan", "inflatable bounce game", "pitch", "paper", "arcade, colonnade", "hot tub", "helicopter", "tray", "partition, divider", "vineyard", "bowl", "bullring", "flag", "pot", "footbridge, overcrossing, pedestrian bridge", "shower", "bag, traveling bag, travelling bag, grip, suitcase", "bulletin board, notice board", "confessional booth", "trunk, tree trunk, bole", "forest", "elevator door", "laptop, laptop computer", "instrument panel", "bucket, pail", "tapestry, tapis", "platform", "jacket", "gate", "monitor, monitoring device", "telephone booth, phone booth, call box, telephone box, telephone kiosk", "spotlight, spot", "ring", "control panel", "blackboard, chalkboard", "air conditioner, air conditioning", "chest", "clock", "sand dune", "pipe, pipage, piping", "vault", "table football", "cannon", "swimming pool, swimming bath, natatorium", "fluorescent, fluorescent fixture", "statue", "loudspeaker, speaker, speaker unit, loudspeaker system, speaker system", "exhibitor", "ladder", "carport", "dam", "pulpit", "skylight, fanlight", "water tower", "grill, grille, grillwork", "display board", "pane, pane of glass, window glass", "rubbish, trash, scrap", "ice rink", "fruit", "patio", "vending machine", "telephone, phone, telephone set", "net", "backpack, back pack, knapsack, packsack, rucksack, haversack", "jar", "track", "magazine", "shutter", "roof", "banner, streamer", "landfill", "post", "altarpiece, reredos", "hat, chapeau, lid", "arch, archway", "table game", "bag, handbag, pocketbook, purse", "document, written document, papers", "dome", "pier", "shanties", "forecourt", "crane", "dog, domestic dog, canis familiaris", "piano, pianoforte, forte-piano", "drawing", "cabin", "ad, advertisement, advertizement, advertising, advertizing, advert", "amphitheater, amphitheatre, coliseum", "monument", "henhouse", "cockpit", "heater, warmer", "windmill, aerogenerator, wind generator", "pool", "elevator, lift", "decoration, ornament, ornamentation", "labyrinth", "text, textual matter", "printer", "mezzanine, first balcony", "mattress", "straw", "stalls", "patio, terrace", "billboard, hoarding", "bus stop", "trouser, pant", "console table, console", "rack", "notebook", "shrine", "pantry", "cart", "steam shovel", "porch", "postbox, mailbox, letter box", "figurine, statuette", "recycling bin", "folding screen", "telescope", "deck chair, beach chair", "kennel", "coffee maker", "altar, communion table, lord's table", "fish", "easel", "artificial golf green", "iceberg", "candlestick, candle holder", "shower stall, shower bath", "television stand", "wall socket, wall plug, electric outlet, electrical outlet, outlet, electric receptacle", "skeleton", "grand piano, grand", "candy, confect", "grille door", "pedestal, plinth, footstall", "jersey, t-shirt, tee shirt", "shoe", "gravestone, headstone, tombstone", "shanty", "structure", "rocking chair, rocker", "bird", "place mat", "tomb", "big top", "gas pump, gasoline pump, petrol pump, island dispenser", "lockers", "cage", "finger", "bleachers", "ferris wheel", "hairdresser chair", "mat", "stands", "aquarium, fish tank, marine museum", "streetcar, tram, tramcar, trolley, trolley car", "napkin, table napkin, serviette", "dummy", "booklet, brochure, folder, leaflet, pamphlet", "sand trap", "shop, store", "table cloth", "service station", "coffin", "drawer", "cages", "slot machine, coin machine", "balcony", "volleyball court", "table tennis", "control table", "shirt", "merchandise, ware, product", "railway", "parterre", "chimney", "can, tin, tin can", "tanks", "fabric, cloth, material, textile", "alga, algae", "system", "map", "greenhouse", "mug", "barbecue", "trailer", "toilet tissue, toilet paper, bathroom tissue", "organ", "dishrag, dishcloth", "island", "keyboard", "trench", "basket, basketball hoop, hoop", "steering wheel, wheel", "pitcher, ewer", "goal", "bread, breadstuff, staff of life", "beds", "wood", "file cabinet", "newspaper, paper", "motorboat", "rope", "guitar", "rubble", "scarf", "barrels", "cap", "leaves", "control tower", "dashboard", "bandstand", "lectern", "switch, electric switch, electrical switch", "baseboard, mopboard, skirting board", "shower room", "smoke", "faucet, spigot", "bulldozer", "saucepan", "shops", "meter", "crevasse", "gear", "candelabrum, candelabra", "sofa bed", "tunnel", "pallet", "wire, conducting wire", "kettle, boiler", "bidet", "baby buggy, baby carriage, carriage, perambulator, pram, stroller, go-cart, pushchair, pusher", "music stand", "pipe, tube", "cup", "parking meter", "ice hockey rink", "shelter", "weeds", "temple", "patty, cake", "ski slope", "panel", "wallet", "wheel", "towel rack, towel horse", "roundabout", "canister, cannister, tin", "rod", "soap dispenser", "bell", "canvas", "box office, ticket office, ticket booth", "teacup", "trellis", "workbench", "valley, vale", "toaster", "knife", "podium", "ramp", "tumble dryer", "fireplug, fire hydrant, plug", "gym shoe, sneaker, tennis shoe", "lab bench", "equipment", "rocky formation", "plastic", "calendar", "caravan", "check-in-desk", "ticket counter", "brush", "mill", "covered bridge", "bowling alley", "hanger", "excavator", "trestle", "revolving door", "blast furnace", "scale, weighing machine", "projector", "soap", "locker", "tractor", "stretcher", "frame", "grating", "alembic", "candle, taper, wax light", "barrier", "cardboard", "cave", "puddle", "tarp", "price tag", "watchtower", "meters", "light bulb, lightbulb, bulb, incandescent lamp, electric light, electric-light bulb", "tracks", "hair dryer", "skirt", "viaduct", "paper towel", "coat", "sheet", "fire extinguisher, extinguisher, asphyxiator", "water wheel", "pottery, clayware", "magazine rack", "teapot", "microphone, mike", "support", "forklift", "canyon", "cash register, register", "leaf, leafage, foliage", "remote control, remote", "soap dish", "windshield, windscreen", "cat", "cue, cue stick, pool cue, pool stick", "vent, venthole, vent-hole, blowhole", "videos", "shovel", "eaves", "antenna, aerial, transmitting aerial", "shipyard", "hen, biddy", "traffic cone", "washing machines", "truck crane", "cds", "niche", "scoreboard", "briefcase", "boot", "sweater, jumper", "hay", "pack", "bottle rack", "glacier", "pergola", "building materials", "television camera", "first floor", "rifle", "tennis table", "stadium", "safety belt", "cover", "dish rack", "synthesizer", "pumpkin", "gutter", "fruit stand", "ice floe, floe", "handle, grip, handgrip, hold", "wheelchair", "mousepad, mouse mat", "diploma", "fairground ride", "radio", "hotplate", "junk", "wheelbarrow", "stream", "toll plaza", "punching bag", "trough", "throne", "chair desk", "weighbridge", "extractor fan", "hanging clothes", "dish, dish aerial, dish antenna, saucer", "alarm clock, alarm", "ski lift", "chain", "garage", "mechanical shovel", "wine rack", "tramway", "treadmill", "menu", "block", "well", "witness stand", "branch", "duck", "casserole", "frying pan", "desk organizer", "mast", "spectacles, specs, eyeglasses, glasses", "service elevator", "dollhouse", "hammock", "clothes hanging", "photocopier", "notepad", "golf cart", "footpath", "cross", "baptismal font", "boiler", "skip", "rotisserie", "tables", "water mill", "helmet", "cover curtain", "brick", "table runner", "ashtray", "street box", "stick", "hangers", "cells", "urinal", "centerpiece", "portable fridge", "dvds", "golf club", "skirting board", "water cooler", "clipboard", "camera, photographic camera", "pigeonhole", "chips", "food processor", "post box", "lid", "drum", "blender", "cave entrance", "dental chair", "obelisk", "canoe", "mobile", "monitors", "pool ball", "cue rack", "baggage carts", "shore", "fork", "paper filer", "bicycle rack", "coat rack", "garland", "sports bag", "fish tank", "towel dispenser", "carriage", "brochure", "plaque", "stringer", "iron", "spoon", "flag pole", "toilet brush", "book stand", "water faucet, water tap, tap, hydrant", "ticket office", "broom", "dvd", "ice bucket", "carapace, shell, cuticle, shield", "tureen", "folders", "chess", "root", "sewing machine", "model", "pen", "violin", "sweatshirt", "recycling materials", "mitten", "chopping board, cutting board", "mask", "log", "mouse, computer mouse", "grill", "hole", "target", "trash bag", "chalk", "sticks", "balloon", "score", "hair spray", "roll", "runner", "engine", "inflatable glove", "games", "pallets", "baskets", "coop", "dvd player", "rocking horse", "buckets", "bread rolls", "shawl", "watering can", "spotlights", "post-it", "bowls", "security camera", "runner cloth", "lock", "alarm, warning device, alarm system", "side", "roulette", "bone", "cutlery", "pool balls", "wheels", "spice rack", "plant pots", "towel ring", "bread box", "video", "funfair", "breads", "tripod", "ironing board", "skimmer", "hollow", "scratching post", "tricycle", "file box", "mountain pass", "tombstones", "cooker", "card game, cards", "golf bag", "towel paper", "chaise lounge", "sun", "toilet paper holder", "rake", "key", "umbrella stand", "dartboard", "transformer", "fireplace utensils", "sweatshirts", "cellular telephone, cellular phone, cellphone, cell, mobile phone", "tallboy", "stapler", "sauna", "test tube", "palette", "shopping carts", "tools", "push button, push, button", "star", "roof rack", "barbed wire", "spray", "ear", "sponge", "racket", "tins", "eyeglasses", "file", "scarfs", "sugar bowl", "flip flop", "headstones", "laptop bag", "leash", "climbing frame", "suit hanger", "floor spotlight", "plate rack", "sewer", "hard drive", "sprinkler", "tools box", "necklace", "bulbs", "steel industry", "club", "jack", "door bars", "control panel, instrument panel, control board, board, panel", "hairbrush", "napkin holder", "office", "smoke detector", "utensils", "apron", "scissors", "terminal", "grinder", "entry phone", "newspaper stand", "pepper shaker", "onions", "central processing unit, cpu, c p u , central processor, processor, mainframe", "tape", "bat", "coaster", "calculator", "potatoes", "luggage rack", "salt", "street number", "viewpoint", "sword", "cd", "rowing machine", "plug", "andiron, firedog, dog, dog-iron", "pepper", "tongs", "bonfire", "dog dish", "belt", "dumbbells", "videocassette recorder, vcr", "hook", "envelopes", "shower faucet", "watch", "padlock", "swimming pool ladder", "spanners", "gravy boat", "notice board", "trash bags", "fire alarm", "ladle", "stethoscope", "rocket", "funnel", "bowling pins", "valve", "thermometer", "cups", "spice jar", "night light", "soaps", "games table", "slotted spoon", "reel", "scourer", "sleeping robe", "desk mat", "dumbbell", "hammer", "tie", "typewriter", "shaker", "cheese dish", "sea star", "racquet", "butane gas cylinder", "paper weight", "shaving brush", "sunglasses", "gear shift", "towel rail", "adding machine, totalizer, totaliser"),
        # palette=[[128, 0, 0], [0, 128, 0], [0, 0, 192],
        #          [128, 128, 0], [128, 0, 128], [0, 128, 128], [192, 128, 64],
        #          [64, 0, 0], [192, 0, 0], [64, 128, 0], [192, 128, 0],
        #          [64, 0, 128], [192, 0, 128], [64, 128, 128], [192, 128, 128],
        #          [0, 64, 0], [128, 64, 0], [0, 192, 0], [128, 192, 0],
        #          [0, 64, 128]])
    )

    def __init__(self,
                 ann_file,
                 img_suffix='.jpg',
                 seg_map_suffix='.tif',
                 reduce_zero_label=False,
                 **kwargs) -> None:
        super().__init__(
            img_suffix=img_suffix,
            seg_map_suffix=seg_map_suffix,
            reduce_zero_label=reduce_zero_label,
            ann_file=ann_file,
            **kwargs)
        assert fileio.exists(self.data_prefix['img_path'],
                             self.backend_args) and osp.isfile(self.ann_file)

@DATASETS.register_module()
class PascalContext459Dataset(BaseSegDataset):
    METAINFO = dict(
        classes=("accordion", "aeroplane", "airconditioner", "antenna", "artillery", "ashtray", "atrium",
                 "babycarriage", "bag", "ball", "balloon", "bambooweaving", "barrel", "baseballbat", "basket",
                 "basketballbackboard", "bathtub", "bed", "bedclothes", "beer", "bell", "bench", "bicycle",
                 "binoculars",
                 "bird", "birdcage", "birdfeeder", "birdnest", "blackboard", "board", "boat", "bone", "book", "bottle",
                 "bottleopener", "bowl", "box", "bracelet", "brick", "bridge", "broom", "brush", "bucket", "building",
                 "bus", "cabinet", "cabinetdoor", "cage", "cake", "calculator", "calendar", "camel", "camera",
                 "cameralens", "can", "candle", "candleholder", "cap", "car", "card", "cart", "case", "casetterecorder",
                 "cashregister", "cat", "cd", "cdplayer", "ceiling", "cellphone", "cello", "chain", "chair",
                 "chessboard",
                 "chicken", "chopstick", "clip", "clippers", "clock", "closet", "cloth", "clothestree", "coffee",
                 "coffeemachine", "comb", "computer", "concrete", "cone", "container", "controlbooth", "controller",
                 "cooker", "copyingmachine", "coral", "cork", "corkscrew", "counter", "court", "cow", "crabstick",
                 "crane", "crate", "cross", "crutch", "cup", "curtain", "cushion", "cuttingboard", "dais", "disc",
                 "disccase", "dishwasher", "dock", "dog", "dolphin", "door", "drainer", "dray", "drinkdispenser",
                 "drinkingmachine", "drop", "drug", "drum", "drumkit", "duck", "dumbbell", "earphone", "earrings",
                 "egg", "electricfan", "electriciron", "electricpot", "electricsaw", "electronickeyboard", "engine",
                 "envelope", "equipment", "escalator", "exhibitionbooth", "extinguisher", "eyeglass", "fan", "faucet",
                 "faxmachine", "fence", "ferriswheel", "fireextinguisher", "firehydrant", "fireplace", "fish",
                 "fishtank",
                 "fishbowl", "fishingnet", "fishingpole", "flag", "flagstaff", "flame", "flashlight", "floor", "flower",
                 "fly", "foam", "food", "footbridge", "forceps", "fork", "forklift", "fountain", "fox", "frame",
                 "fridge",
                 "frog", "fruit", "funnel", "furnace", "gamecontroller", "gamemachine", "gascylinder", "gashood",
                 "gasstove",
                 "giftbox", "glass", "glassmarble", "globe", "glove", "goal", "grandstand", "grass", "gravestone",
                 "ground",
                 "guardrail", "guitar", "gun", "hammer", "handcart", "handle", "handrail", "hanger", "harddiskdrive",
                 "hat", "hay", "headphone", "heater", "helicopter", "helmet", "holder", "hook", "horse",
                 "horse-drawncarriage",
                 "hot-airballoon", "hydrovalve", "ice", "inflatorpump", "ipod", "iron", "ironingboard", "jar", "kart",
                 "kettle", "key", "keyboard", "kitchenrange", "kite", "knife", "knifeblock", "ladder", "laddertruck",
                 "ladle", "laptop", "leaves", "lid", "lifebuoy", "light", "lightbulb", "lighter", "line", "lion",
                 "lobster",
                 "lock", "machine", "mailbox", "mannequin", "map", "mask", "mat", "matchbook", "mattress", "menu",
                 "metal",
                 "meterbox", "microphone", "microwave", "mirror", "missile", "model", "money", "monkey", "mop",
                 "motorbike",
                 "mountain", "mouse", "mousepad", "musicalinstrument", "napkin", "net", "newspaper", "oar", "ornament",
                 "outlet", "oven", "oxygenbottle", "pack", "pan", "paper", "paperbox", "papercutter", "parachute",
                 "parasol",
                 "parterre", "patio", "pelage", "pen", "pencontainer", "pencil", "person", "photo", "piano", "picture",
                 "pig",
                 "pillar", "pillow", "pipe", "pitcher", "plant", "plastic", "plate", "platform", "player", "playground",
                 "pliers",
                 "plume", "poker", "pokerchip", "pole", "pooltable", "postcard", "poster", "pot", "pottedplant",
                 "printer", "projector",
                 "pumpkin", "rabbit", "racket", "radiator", "radio", "rail", "rake", "ramp", "rangehood", "receiver",
                 "recorder",
                 "recreationalmachines", "remotecontrol", "road", "robot", "rock", "rocket", "rockinghorse", "rope",
                 "rug", "ruler",
                 "runway", "saddle", "sand", "saw", "scale", "scanner", "scissors", "scoop", "screen", "screwdriver",
                 "sculpture",
                 "scythe", "sewer", "sewingmachine", "shed", "sheep", "shell", "shelves", "shoe", "shoppingcart",
                 "shovel", "sidecar",
                 "sidewalk", "sign", "signallight", "sink", "skateboard", "ski", "sky", "sled", "slippers", "smoke",
                 "snail", "snake",
                 "snow", "snowmobiles", "sofa", "spanner", "spatula", "speaker", "speedbump", "spicecontainer", "spoon",
                 "sprayer",
                 "squirrel", "stage", "stair", "stapler", "stick", "stickynote", "stone", "stool", "stove", "straw",
                 "stretcher", "sun",
                 "sunglass", "sunshade", "surveillancecamera", "swan", "sweeper", "swimring", "swimmingpool", "swing",
                 "switch", "table",
                 "tableware", "tank", "tap", "tape", "tarp", "telephone", "telephonebooth", "tent", "tire", "toaster",
                 "toilet", "tong",
                 "tool", "toothbrush", "towel", "toy", "toycar", "track", "train", "trampoline", "trashbin", "tray",
                 "tree", "tricycle",
                 "tripod", "trophy", "truck", "tube", "turtle", "tvmonitor", "tweezers", "typewriter", "umbrella",
                 "unknown", "vacuumcleaner",
                 "vendingmachine", "videocamera", "videogameconsole", "videoplayer", "videotape", "violin", "wakeboard",
                 "wall", "wallet",
                 "wardrobe", "washingmachine", "watch", "water", "waterdispenser", "waterpipe", "waterskateboard",
                 "watermelon", "whale",
                 "wharf", "wheel", "wheelchair", "window", "windowblinds", "wineglass", "wire", "wood", "wool"),
    )

    def __init__(self,
                 ann_file,
                 img_suffix='.jpg',
                 seg_map_suffix='.tif',
                 reduce_zero_label=False,
                 **kwargs):
        super().__init__(
            img_suffix=img_suffix,
            seg_map_suffix=seg_map_suffix,
            ann_file=ann_file,
            reduce_zero_label=reduce_zero_label,
            **kwargs)


@TRANSFORMS.register_module()
class MyLoadAnnotations(MMCV_LoadAnnotations):
    """Load annotations for semantic segmentation provided by dataset.

    The annotation format is as the following:

    .. code-block:: python

        {
            # Filename of semantic segmentation ground truth file.
            'seg_map_path': 'a/b/c'
        }

    After this module, the annotation has been changed to the format below:

    .. code-block:: python

        {
            # in str
            'seg_fields': List
             # In uint8 type.
            'gt_seg_map': np.ndarray (H, W)
        }

    Required Keys:

    - seg_map_path (str): Path of semantic segmentation ground truth file.

    Added Keys:

    - seg_fields (List)
    - gt_seg_map (np.uint8)

    Args:
        reduce_zero_label (bool, optional): Whether reduce all label value
            by 1. Usually used for datasets where 0 is background label.
            Defaults to None.
        imdecode_backend (str): The image decoding backend type. The backend
            argument for :func:``mmcv.imfrombytes``.
            See :fun:``mmcv.imfrombytes`` for details.
            Defaults to 'pillow'.
        backend_args (dict): Arguments to instantiate a file backend.
            See https://mmengine.readthedocs.io/en/latest/api/fileio.htm
            for details. Defaults to None.
            Notes: mmcv>=2.0.0rc4, mmengine>=0.2.0 required.
    """

    def __init__(
            self,
            reduce_zero_label=None,
            backend_args=None,
            imdecode_backend='pillow',
    ) -> None:
        super().__init__(
            with_bbox=False,
            with_label=False,
            with_seg=True,
            with_keypoints=False,
            imdecode_backend=imdecode_backend,
            backend_args=backend_args)
        self.reduce_zero_label = reduce_zero_label
        if self.reduce_zero_label is not None:
            warnings.warn('`reduce_zero_label` will be deprecated, '
                          'if you would like to ignore the zero label, please '
                          'set `reduce_zero_label=True` when dataset '
                          'initialized')
        self.imdecode_backend = imdecode_backend

    def _load_seg_map(self, results: dict) -> None:
        """Private function to load semantic segmentation annotations.

        Args:
            results (dict): Result dict from :obj:``mmcv.BaseDataset``.

        Returns:
            dict: The dict contains loaded semantic segmentation annotations.
        """

        img_bytes = fileio.get(
            results['seg_map_path'], backend_args=self.backend_args)
        gt_semantic_seg = mmcv.imfrombytes(
            img_bytes, flag='unchanged',
            backend=self.imdecode_backend).squeeze().astype(np.uint16)

        # reduce zero_label
        if self.reduce_zero_label is None:
            self.reduce_zero_label = results['reduce_zero_label']
        assert self.reduce_zero_label == results['reduce_zero_label'], \
            'Initialize dataset with `reduce_zero_label` as ' \
            f'{results["reduce_zero_label"]} but when load annotation ' \
            f'the `reduce_zero_label` is {self.reduce_zero_label}'
        if self.reduce_zero_label:
            # avoid using underflow conversion
            gt_semantic_seg[gt_semantic_seg == 0] = 255
            gt_semantic_seg = gt_semantic_seg - 1
            gt_semantic_seg[gt_semantic_seg == 254] = 255
        # modify if custom classes
        if results.get('label_map', None) is not None:
            # Add deep copy to solve bug of repeatedly
            # replace `gt_semantic_seg`, which is reported in
            # https://github.com/open-mmlab/mmsegmentation/pull/1445/
            gt_semantic_seg_copy = gt_semantic_seg.copy()
            for old_id, new_id in results['label_map'].items():
                gt_semantic_seg[gt_semantic_seg_copy == old_id] = new_id
        results['gt_seg_map'] = gt_semantic_seg
        results['seg_fields'].append('gt_seg_map')

    def __repr__(self) -> str:
        repr_str = self.__class__.__name__
        repr_str += f'(reduce_zero_label={self.reduce_zero_label}, '
        repr_str += f"imdecode_backend='{self.imdecode_backend}', "
        repr_str += f'backend_args={self.backend_args})'
        return repr_str