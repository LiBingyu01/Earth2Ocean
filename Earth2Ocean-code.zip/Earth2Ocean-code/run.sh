#!/bin/bash
WORK_DIR_BASE="work_logs"
MODEL_TYPE=(ViT-B/16 ViT-L-14 ViT-H-14)    # "ViT-B/16", "ViT-L-14", "ViT-H-14"
BETA=1.2
GAMMA=3.0
VFM_MODEL="geometric"
GEOFEATS_IDX=3
SIMILARITY_THRES=0.5
MAX_WEIGHT=0.5
MLLM_TYPE="qwen7b" # 4o qwen3b qwen7b

for model in "${MODEL_TYPE[@]}"; do
    echo "Running experiment with:
            WORK_DIR_BASE=$WORK_DIR_BASE,
            MODEL_TYPE=$model,
            BETA=$BETA,
            GAMMA=$GAMMA,
            VFM_MODEL=$VFM_MODEL,
            GEOFEATS_IDX=$GEOFEATS_IDX,
            SIMILARITY_THRES=$SIMILARITY_THRES,
            MAX_WEIGHT=$MAX_WEIGHT,
            MLLM_TYPE=$MLLM_TYPE"

    sh dist_test.sh \
        "$WORK_DIR_BASE" \
        "$model" \
        "$BETA" \
        "$GAMMA" \
        "$VFM_MODEL" \
        "$GEOFEATS_IDX" \
        "$SIMILARITY_THRES" \
        "$MAX_WEIGHT" \
        "$MLLM_TYPE"
done