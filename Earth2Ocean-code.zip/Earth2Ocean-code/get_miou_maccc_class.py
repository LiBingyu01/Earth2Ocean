import os
import json
import pandas as pd
import argparse

def extract_table_from_log(log_path):
    start_marker = "+--------------------------+-------+-------+"
    with open(log_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    start_indices = [i for i, line in enumerate(lines) if start_marker in line]
    if len(start_indices) < 3:
        raise ValueError(f"Expected 3 table markers in {log_path}, found {len(start_indices)}.")

    start_idx = start_indices[0]
    end_idx = start_indices[2]
    table_lines = lines[start_idx:end_idx + 1]
    table_data = [line for line in table_lines if "|" in line and not line.startswith("+")]

    parsed_rows = []
    for line in table_data:
        parts = [p.strip() for p in line.split("|")[1:-1]]
        if len(parts) == 3 and parts[0] != "Class":
            try:
                iou = float(parts[1].replace("%", "").strip())
                acc = float(parts[2].replace("%", "").strip())
                parsed_rows.append({"Class": parts[0], "IoU": iou, "Acc": acc})
            except ValueError:
                continue

    df = pd.DataFrame(parsed_rows)
    return df

def compute_group_stats(df, category_dict, class_name_to_id, name):
    results = {}
    for key, info in category_dict.items():
        ids = set(info.get("ids", []))
        if not ids:
            continue

        mask = df["Class"].apply(lambda x: class_name_to_id.get(x.lower(), -1) in ids)
        subset = df[mask]
        if len(subset) > 0:
            miou = subset["IoU"].mean()
            macc = subset["Acc"].mean()
        else:
            miou = macc = 0.0
        results[key] = {"mIoU": round(miou, 2), "mAcc": round(macc, 2)}
    return results

def process_log_file(json_data, log_path, output_base):
    id_to_name = {int(k): v for k, v in json_data["id_to_name"].items()}
    class_name_to_id = {v.lower(): k for k, v in id_to_name.items()}

    df = extract_table_from_log(log_path)
    res1 = compute_group_stats(df, json_data["categories1"], class_name_to_id, "Categories 1")
    res2 = compute_group_stats(df, json_data["categories2"], class_name_to_id, "Categories 2")

    # 构造输出路径，保持文件夹结构
    rel_path = os.path.relpath(log_path, start=args.input_dir)
    out_path = os.path.join(output_base, os.path.splitext(rel_path)[0] + ".txt")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(f"Results from {log_path}\n\n")
        for name, res in [("Categories 1", res1), ("Categories 2", res2)]:
            f.write(f"===== {name} =====\n")
            for k, v in res.items():
                f.write(f"{k:<30s} mIoU: {v['mIoU']:<6.2f}  mAcc: {v['mAcc']:<6.2f}\n")
            f.write("\n")
    print(f"[INFO] Saved results to {out_path}")

def main(json_path, input_dir, output_dir):
    with open(json_path, "r", encoding="utf-8") as f:
        json_data = json.load(f)

    for root, _, files in os.walk(input_dir):
        for file in files:
            if file.endswith(".log"):
                log_path = os.path.join(root, file)
                try:
                    process_log_file(json_data, log_path, output_dir)
                except Exception as e:
                    print(f"[ERROR] Failed to process {log_path}: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process multiple .log files in folders and save stats.")
    parser.add_argument("--json_path", required=True, help="Path to JSON file defining categories")
    parser.add_argument("--input_dir", required=True, help="Parent directory containing .log files")
    parser.add_argument("--output_dir", required=True, help="Output directory for result .txt files")
    args = parser.parse_args()

    main(args.json_path, args.input_dir, args.output_dir)
